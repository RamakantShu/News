export interface IProperty {
  id: number;
  parent_id: number;
  code: string;
  name: string;
}