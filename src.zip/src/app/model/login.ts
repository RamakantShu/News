export class Login {
    LoginId: string;
    Password: string;
    constructor() { 
    }
}
