namespace webapi.ViewModel
{
    public class Products
    {
        public int id{get;set;}
        public int name {get;set;}
    }
}
